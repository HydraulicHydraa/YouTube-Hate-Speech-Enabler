import tk
from tkinter import Tk
import pyperclip

#The title stands for 'Homo(Sexual)Glyph Generator'

THINGY = pyperclip.paste()

#While True:
#	if "a" or "b" or "c" or "d" or "e" or "f" or "g" or "h" or "i" or "j" or "k" or "l" or "m" or "n" or "o" or "p" 
#	or "q" or "r" or "s" or "t" or "u" or "v" or "w" or "x" or "y" or "z" or "A" or "B" or "C" or "D" or "E" or "F" 
#	or "G" or "H" or "J" or "K" or "L" or "M" or "N" or "" or "" or "" or "" or "" or "" or "" or "" or "" 
#	or "" or "" or "" or "" or

THINGY = THINGY.replace("a", "ā")
THINGY = THINGY.replace("b", "β")
THINGY = THINGY.replace("c", "č")
THINGY = THINGY.replace("d", "ȡ")
THINGY = THINGY.replace("e", "℮")
THINGY = THINGY.replace("f", "ʄ")
THINGY = THINGY.replace("g", "ġ")
THINGY = THINGY.replace("h", "ḥ")
THINGY = THINGY.replace("i", "ỉ")
THINGY = THINGY.replace("j", "ℐ")
THINGY = THINGY.replace("k", "ḱ")
THINGY = THINGY.replace("l", "ι")
THINGY = THINGY.replace("m", "ṁ")
THINGY = THINGY.replace("n", "η")
THINGY = THINGY.replace("o", "ο")
THINGY = THINGY.replace("p", "ρ")
THINGY = THINGY.replace("q", "զ")
THINGY = THINGY.replace("r", "ℾ")
THINGY = THINGY.replace("s", "ʂ")
THINGY = THINGY.replace("t", "τ")
THINGY = THINGY.replace("u", "μ")
THINGY = THINGY.replace("v", "ν")
THINGY = THINGY.replace("w", "ω")
THINGY = THINGY.replace("x", "メ")
THINGY = THINGY.replace("y", "ℽ")
THINGY = THINGY.replace("z", "ẑ")
THINGY = THINGY.replace("A", "Å")
THINGY = THINGY.replace("B", "Β")
THINGY = THINGY.replace("C", "Č")
THINGY = THINGY.replace("D", "Ď")
THINGY = THINGY.replace("E", "Ε")
THINGY = THINGY.replace("F", "₣")
THINGY = THINGY.replace("G", "Ḡ")
THINGY = THINGY.replace("H", "Η")
THINGY = THINGY.replace("I", "エ")
THINGY = THINGY.replace("J", "ℑ")
THINGY = THINGY.replace("K", "Κ")
THINGY = THINGY.replace("L", "Ł")
THINGY = THINGY.replace("M", "Μ")
THINGY = THINGY.replace("N", "ℵ")
THINGY = THINGY.replace("O", "Ο")
THINGY = THINGY.replace("P", "Ρ")
THINGY = THINGY.replace("Q", "Ǭ")
THINGY = THINGY.replace("R", "℟")
THINGY = THINGY.replace("S", "δ")
THINGY = THINGY.replace("T", "Τ")
THINGY = THINGY.replace("U", "℧")
THINGY = THINGY.replace("V", "℣")
THINGY = THINGY.replace("W", "Ψ")
THINGY = THINGY.replace("X", "χ")
THINGY = THINGY.replace("Y", "γ")
THINGY = THINGY.replace("Z", "Ζ")

pyperclip.copy(THINGY)