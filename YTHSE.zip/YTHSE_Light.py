import tk
from tkinter import Tk
import pyperclip

#The title stands for 'Homo(Sexual)Glyph Generator'

THINGY = pyperclip.paste()

#While True:
#	if "a" or "b" or "c" or "d" or "e" or "f" or "g" or "h" or "i" or "j" or "k" or "l" or "m" or "n" or "o" or "p" 
#	or "q" or "r" or "s" or "t" or "u" or "v" or "w" or "x" or "y" or "z" or "A" or "B" or "C" or "D" or "E" or "F" 
#	or "G" or "H" or "J" or "K" or "L" or "M" or "N" or "" or "" or "" or "" or "" or "" or "" or "" or "" 
#	or "" or "" or "" or "" or

THINGY = THINGY.replace("a", "а")
THINGY = THINGY.replace("b", "b")
THINGY = THINGY.replace("c", "c")
THINGY = THINGY.replace("d", "d")
THINGY = THINGY.replace("e", "e")
THINGY = THINGY.replace("f", "ғ")
THINGY = THINGY.replace("g", "g")
THINGY = THINGY.replace("h", "h")
THINGY = THINGY.replace("i", "i")
THINGY = THINGY.replace("j", "j")
THINGY = THINGY.replace("k", "k")
THINGY = THINGY.replace("l", "ⅼ")
THINGY = THINGY.replace("m", "ⅿ")
THINGY = THINGY.replace("n", "n")
THINGY = THINGY.replace("o", "o")
THINGY = THINGY.replace("p", "p")
THINGY = THINGY.replace("q", "q")
THINGY = THINGY.replace("r", "г")
THINGY = THINGY.replace("s", "s")
THINGY = THINGY.replace("t", "τ")
THINGY = THINGY.replace("u", "υ")
THINGY = THINGY.replace("v", "v")
THINGY = THINGY.replace("w", "ѡ")
THINGY = THINGY.replace("x", "x")
THINGY = THINGY.replace("y", "y")
THINGY = THINGY.replace("z", "z")
THINGY = THINGY.replace("A", "Α")
THINGY = THINGY.replace("B", "Β")
THINGY = THINGY.replace("C", "Ϲ")
THINGY = THINGY.replace("D", "Ⅾ")
THINGY = THINGY.replace("E", "Ε")
THINGY = THINGY.replace("F", "Ғ")
THINGY = THINGY.replace("G", "Ԍ")
THINGY = THINGY.replace("H", "Η")
THINGY = THINGY.replace("I", "Ι")
THINGY = THINGY.replace("J", "Ј")
THINGY = THINGY.replace("K", "Κ")
THINGY = THINGY.replace("L", "Ⅼ")
THINGY = THINGY.replace("M", "Μ")
THINGY = THINGY.replace("N", "Ν")
THINGY = THINGY.replace("O", "Ο")
THINGY = THINGY.replace("P", "Ρ")
THINGY = THINGY.replace("Q", "Ԛ")
THINGY = THINGY.replace("R", "R")
THINGY = THINGY.replace("S", "Ѕ")
THINGY = THINGY.replace("T", "Τ")
THINGY = THINGY.replace("U", "⋃")
THINGY = THINGY.replace("V", "Ⅴ")
THINGY = THINGY.replace("W", "W")
THINGY = THINGY.replace("X", "Χ")
THINGY = THINGY.replace("Y", "Ү")
THINGY = THINGY.replace("Z", "Ζ")

pyperclip.copy(THINGY)